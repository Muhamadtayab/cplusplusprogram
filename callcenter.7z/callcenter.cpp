#include <iostream>
#include <fstream>
#include<string>
#include <cctype>
#include<cstdlib>
#include<sstream>

using namespace std;
//phone number exist check for call record
bool isPhoneDuplicateCall(const string& phone) {
    string line, id, name, contact, address;
    ifstream infile("call.txt");

    while (getline(infile, line)) {
        stringstream ss(line);
        getline(ss, id, '|');
        getline(ss, name, '|');
        getline(ss, contact, '|');  
        if (contact == phone) {
            return true;
        }
    }
    return false;
}
//phone number exist check for company
bool isPhoneDuplicate(const string& phone) {
    string line, id, name, contact, address;
    ifstream infile("company.txt");

    while (getline(infile, line)) {
        stringstream ss(line);
        getline(ss, id, '|');
        getline(ss, name, '|');
        getline(ss, contact, '|');  
        if (contact == phone) {
            return true;
        }
    }
    return false;
}

//company exist ka function
bool ifcompanyExists(const string& comp) {
    string id, name, contact, address,line;
    ifstream infile("company.txt");
   while (getline(infile,line)) {
   	stringstream ss(line);
   	getline(ss,id,'|');
   	getline(ss,name,'|');
   	getline(ss,contact,'|');
   	getline(ss,address,'|');
        if (name == comp) {
            return true; 
        }
    }
    return false;
}
//add call record karta hua employ ki id exixt karti ka nai uska function
bool ifEmployeeExists(const string& idd) {
    string Id, name, gender, comp_name, shift,line;
    ifstream infile("employ.txt");
    while (getline(infile,line)) {
    	stringstream ss(line);
    	getline(ss,Id,'|');
        if (Id == idd) {
            return true; 
        }
    }
    return false;
}

//employ ki id repeat naw ho uska function
bool ifRpeatId(string idd){
	string Id,name,gender,comp_name,shift,line;
	ifstream infile("employ.txt");
	while(getline(infile,line)){
		stringstream ss(line);
		getline(ss,Id,'|');
		if(Id==idd){
			return true;
		}
	}
	return false;
}
//company ki id check
bool isCompanyIdExist(string id){
    string compId, name, contact, address,line;
    ifstream infile("company.txt");
   	while(getline(infile,line)){
		stringstream ss(line);
		getline(ss,compId,'|');
		if(compId==id){
			return true;
		}
    }
    return false;
}

//name ki validation ka liya ka koi integer ya char use naw ho uska function
bool isValidName(const string& text) {
    for (int i = 0; i < text.length(); i++) {
        if (!isalpha(text[i]) && text[i] != ' ')
            return false;
    }
    return true;
    
}
//phone number ki validation ka function
bool isValidPhone(const string& number) {
    for (int i = 0; i < number.length(); i++) {
        if (!isdigit(number[i]))
            return false;
    }
    return number.length() == 11;
}
//gender ki validation ka function
bool isValidGender(string gender) {
    
    for (int i = 0; i < gender.length(); i++) {
        gender[i] = tolower(gender[i]);
    }

    if (gender == "male" || gender == "female" ) {
        return true;
    } else {
        return false;
    }
}
//employ ki mangaments ka functions
void employdata(){
	string id,name,gender,comp_name,shift;
		ofstream outfile("employ.txt",ios::app);
			if(!outfile){
				cout<<"error opening file for writing";
				
			}
			
			cout<<"Employ id:";
			getline(cin,id);
		while(ifRpeatId(id)==true){
			cout<<"id number already exist use another id number:";
		getline(cin,id);
		}	
		
			cout << "Employ name:";
    getline(cin, name);
    while (isValidName(name)==false) {
        cout << "Invalid name. Try again: ";
        getline(cin, name);
    }
			
			cout<<"Gender:";
			getline(cin,gender);
			while(isValidGender(gender)==false){
				cout<<"invalid gender."<<endl;
				cout<<"enter valid gender(Male/female)";
					getline(cin,gender);
			}
			
			cout<<"Company name they work for:";
			getline(cin ,comp_name);
			while (isValidName(comp_name)==false) {
        cout << "Invalid name. Try again: ";
        getline(cin, comp_name);
    }
		while(ifcompanyExists(comp_name)==false){
			cout<<"this company does not exid plz enter valid company:";
			getline(cin ,comp_name);
		}	
			while (isValidName(comp_name)==false) {
        cout << "Invalid name. Try again: ";
        getline(cin, comp_name);
    }
			
			cout<<"Shift time:";
			getline(cin ,shift);
		
			outfile<<id<<"|"<<name<<"|"<<gender<<"|"<<comp_name<<"|"<<shift<<endl;
			outfile.close();
			cout<<"Data add succesfully.";
		}
		
		void updateEmployData(){
			string Id,name,gender,comp_name,shift,line;
			cout<<"----Update company data----"<<endl;		
					ifstream infile("employ.txt");
					ofstream outfile("temp.txt");
					if(!infile){
						cout<<"error opening file for reading.";
						
					}
					string searchId;
					cout<<"enter employ id for update:";
					getline(cin ,searchId);
					int found=0;
					  while (getline(infile, line)) {
                      stringstream ss(line);
                      getline(ss, Id, '|');
                      getline(ss, name, '|');
                      getline(ss, gender, '|');
                      getline(ss, comp_name, '|');
                      getline(ss, shift, '|');
						if(searchId==Id){
							
							cout<<"enter new employe id:";
							getline(cin ,Id);
							while(ifRpeatId(Id)==true){
			cout<<"id number already exist use another id number:";
	        	getline(cin,Id);
		}	
							cout<<"enter new employe name:";
							getline(cin ,name);
							while (isValidName(name)==false) {
        cout << "Invalid name. Try again: ";
        getline(cin, name);
    }
    
							cout<<"enter new gender:";
							getline(cin,gender);
								while(isValidGender(gender)==false){
				cout<<"invalid gender."<<endl;
				cout<<"enter valid gender(Male/female)";
					getline(cin,gender);
			}
							cout<<"enter new company name:";
							getline(cin,comp_name);
								while (isValidName(comp_name)==false) {
        cout << "Invalid name. Try again: ";
        getline(cin, comp_name);
    }
    	while(ifcompanyExists(comp_name)==false){
			cout<<"this company does not exid plz enter valid company:";
			getline(cin ,comp_name);
		}
							cout<<"enter new shift:";
							getline(cin,shift);
							found=1;
						}
					outfile<<Id<<"|"<<name<<"|"<<gender<<"|"<<comp_name<<"|"<<shift<<endl;
					}
					infile.close();
					outfile.close();
					
					remove("employ.txt");
					rename("temp.txt","employ.txt");
					if(found==1){
						cout<<"data update succecfully.";
					}else{
						cout<<"data not fount";
					}
					
		}
	void delEmployData(){
		string Id,name,gender,comp_name,shift,line;
			cout<<"----delete company data----"<<endl;		
					ifstream infile("employ.txt");
					ofstream outfile("temp.txt");
					if(!infile){
						cout<<"error opening file for reading.";
					
					}
					string searchId;
					cout<<"enter employ id for delete:";
					getline(cin ,searchId);
					int found=0;
					  while (getline(infile, line)) {
                       stringstream ss(line);
                       getline(ss, Id, '|');
                       getline(ss, name, '|');
                       getline(ss, gender, '|');
                       getline(ss, comp_name, '|');
                       getline(ss, shift, '|');
						if(searchId==Id){
							
							
							found=1;
							continue;
						}
					outfile<<Id<<"|"<<name<<"|"<<gender<<"|"<<comp_name<<"|"<<shift<<endl;
					}
					infile.close();
					outfile.close();
					
					remove("employ.txt");
					rename("temp.txt","employ.txt");
					if(found==1){
						cout<<"data delete succecfully.";
					}else{
						cout<<"data not fount";
					}
	}
	void displayEmployData(){
		string id,name,gender,comp_name,shift,line;
			cout<<"----Display Employe data----"<<endl;
			ifstream infile("employ.txt");
			if(!infile){
				cout<<"error opening file for reading";
				
			}
			while(getline(infile,line)){
				stringstream ss(line);
				
				getline(ss, id,'|');
				getline(ss, name,'|');
				getline(ss, gender,'|');
				getline(ss, comp_name,'|');
				getline(ss, shift,'|');
	
				cout<<"Employee id:"<<id<<endl;
				cout<<"Employe name:"<<name<<endl;
				cout<<"Gender:"<<gender<<endl;
				cout<<"Company name they work for:"<<comp_name<<endl;
				cout<<"Shift time:"<<shift<<endl;
				cout<<"___________"<<endl;
			}
		infile.close();
		}
//		call record system ka functions
	void addCallRecord(){
			string id,name,cont,issue;
		ofstream outfile("call.txt",ios::app);
			if(!outfile){
				cout<<"error opening file for writing\n";
			
			}
			cout<<"employee id:";
			getline(cin,id);
			while(ifEmployeeExists(id)==false){
				cout<<"this id does not exist plz enter valid id:";
				getline(cin,id);
			}
		
			cout<<"custmor name:";
			getline(cin,name);
			while (isValidName(name)==false) {
        cout << "Invalid name. Try again: ";
        getline(cin, name);
    }
			cout<<"contact number:";
			getline(cin,cont);
			while(isValidPhone(cont)==false){
				cout<<"invalid phone number Enter again phone no:"<<endl;
				
				getline(cin ,cont);
			}
		while(isPhoneDuplicateCall(cont)==true)	{
			cout<<"phone number exist:";
			getline(cin ,cont);
		}
			
			cout<<"Issue Type:";
			getline(cin ,issue);
		
			outfile<<id<<"|"<<name<<"|"<<cont<<"|"<<issue<<endl;
			outfile.close();
			cout<<"call record add succesfully.";
	}
void delCallData(){
	string id,name,cont,issue,line;
		cout<<"----delete call record data----"<<endl;		
					ifstream infile("call.txt");
					ofstream outfile("temp.txt");
					if(!infile){
						cout<<"error opening file for reading.";
					
					}
					string searchcont;
					cout<<"enter phone no for delete call record:";
					getline(cin ,searchcont);
					int found=0;
					while(getline(infile,line)){
						stringstream ss(line);
						getline(ss,cont,'|');
						if(searchcont==cont){
							
							
							found=1;
							continue;
						}
						outfile<<id<<"|"<<name<<"|"<<cont<<"|"<<issue<<endl;
					}
					infile.close();
					outfile.close();
					
					remove("call.txt");
					rename("temp.txt","call.txt");
					if(found==1){
						cout<<"data delete succecfully.";
					}else{
						cout<<"data not fount";
					}
}
void diplaycallData(){
	string id,name,cont,issue,line;
	cout<<"----Display call record data----"<<endl;
			ifstream infile("call.txt");
			if(!infile){
				cout<<"error opening file for reading";
				
			}
			while(getline(infile,line)){
				stringstream ss(line);
				getline(ss,id,'|');
				getline(ss,name,'|');
				getline(ss,cont,'|');
				getline(ss,issue,'|');
				
				cout<<"Employee id:"<<id<<endl;
				cout<<"custmor name:"<<name<<endl;
				cout<<"contact no::"<<cont<<endl;
				cout<<"issue type:"<<issue<<endl;
			
				cout<<"___________"<<endl;
			}
		infile.close();
}
void displaySystemInfo() {
    cout << "__________ System Information__________"<<endl;
    cout << "System Name: CallXpert Management System"<<endl;
    cout << "Developer: Muhammad Tayyab"<<endl;
    cout << "Version: 1.0"<<endl;

    // compny informtion
    ifstream infile("company.txt");
    int compCount = 0;
    string id, name, contact, address,line;

    cout << "-----company info-----"<<endl;
    while (getline(infile,line)) {
    	stringstream ss(line);
    	getline(ss,id,'|');
    	getline(ss,name,'|');
    	getline(ss,contact,'|');
    	getline(ss,address,'|');
    	
        compCount++;
        cout << "-> " << name << endl;
    }
    infile.close();
   
    cout << "Total Companies: " << compCount << endl;
cout<<endl;
cout << "-----Employee info-----"<<endl;
//    employ information
    ifstream file("employ.txt");
    int empCount = 0;
    string emp_id, emp_name, gender, comp_name, shift;

    
    while (getline(file,line)) {
    	stringstream ss(line);
    	getline(ss,emp_id,'|');
    	getline(ss,emp_name,'|');
    	getline(ss,gender,'|');
    	getline(ss,comp_name,'|');
    	getline(ss,shift,'|');
    	
        empCount++;
       cout<<"employ ID:"<<emp_id<<endl;
    }
    file.close();
    cout << "Total Employees: " << empCount << endl;

    cout<<endl;
}
void searchEmploy(){
		string id,name,gender,comp_name,shift,line;
					
					ifstream infile("employ.txt");
				
					if(!infile){
						cout<<"error opening file for reading.";
						
					}
					string searchId;
					cout<<"enter employ id for search:";
					getline(cin ,searchId);
					bool found=false;
				while (getline(infile,line)) {
               	stringstream ss(line);
             	getline(ss,id,'|');
            	getline(ss,name,'|');
            	getline(ss,gender,'|');
            	getline(ss,comp_name,'|');
            	getline(ss,shift,'|');
						if(searchId==id){
							
				cout<<"Employe name:"<<name<<endl;
				cout<<"Gender:"<<gender<<endl;
				cout<<"Company name:"<<comp_name<<endl;
				cout<<"Shift time:"<<shift<<endl;
				cout<<"_________"<<endl;
			     	found=true;
				
						}
						
						}
						if(!found){
							cout<<"Id does not exist plz put valid id.";
							getline(cin ,searchId);
						}
}


int main() {
    int choices, choice;
    string name, adress, id, cont;

mainmenu:
    system("cls");
    cout << "----CallXpert Management system----" << endl;
    cout << endl;
    cout << "press 1 for system information." << endl;
    cout << "press 2 for companies information." << endl;
    cout << "press 3 for Employ information." << endl;
    cout << "press 4 for 'call record system'." << endl;
    cout << "press 5 to Exit." << endl;

    cout << "Enter your choice: ";
    cin >> choices;
    while (cin.fail() || choices < 1 || choices > 5) {
    cin.clear(); 
    cin.ignore(1000, '\n'); 
    cout << " Invalid choice. Please enter (1 to 5): ";
    cin >> choices;
}
cin.ignore(); 


 system("cls");
    if (choices == 1) {
       
        displaySystemInfo();
        cout << endl;
        searchEmploy();
        system("pause");
        goto mainmenu;
    } else if (choices == 2) {
    companymenu:
       
        cout << "----Company Management---" << endl;
        cout << "'1' for Add company data." << endl;
        cout << "'2' for Update company data." << endl;
        cout << "'3' for Delete company data." << endl;
        cout << "'4' for Display company data." << endl;
        cout << "'5' to Return to Main Menu." << endl;
        cout << "Enter your choice: ";
        cin>>choice;
         while (cin.fail() || choice < 1 || choice > 5) {
    cin.clear(); 
    cin.ignore(1000, '\n'); 
    cout << " Invalid choice. Please enter (1 to 5): ";
    cin >> choice;
}
        
        cin.ignore();
         system("cls");
        if (choice == 1) {
            
            ofstream outfile("company.txt", ios::app);
            if (!outfile) {
                cout << "error opening file for writing\n";
                return 1;
            }
            cout << "Company ID: ";
            getline(cin, id);
          while (isCompanyIdExist(id)) {
    cout << "ID already exists in company records. Use another ID: ";
    getline(cin, id);
}

            cout << "Company Name: ";
            getline(cin, name);
            while (!isValidName(name)) {
                cout << "Invalid name. Try again : ";
                getline(cin, name);
            }
            while(ifcompanyExists(name)==true){
            	cout<<"this comapny already exist :";
            	getline(cin, name);
            	
			}
            cout << "Contact Number: ";
            getline(cin, cont);
            while (!isValidPhone(cont)) {
                cout << "Invalid phone number. Try again: ";
                getline(cin, cont);
            }
            while(isPhoneDuplicate(cont)==true){
            	cout<<"phone number already exist:";
            	getline(cin, cont);
			}
			
            cout << "Address: ";
            getline(cin, adress);
            outfile << id << "|" << name << "|" << cont << "|" << adress << endl;
            outfile.close();
            cout << "Data added successfully."<<endl;
            system("pause");
            system("cls");
            goto companymenu;
        } else if (choice == 2) {
            
           string Id,Name,Contact,Adress,line;
			cout<<"----Update company data----"<<endl;		
					ifstream infile("company.txt");
					ofstream outfile("temp.txt");
					if(!infile){
						cout<<"error opening file for reading.";
						return 1;
					}
					string searchId;
					cout<<"enter company id for update:";
					getline(cin ,searchId);
					int found=0;
					while(getline(infile,line)){
						stringstream ss(line);
						getline(ss,Id,'|');
						getline(ss,Name,'|');
						getline(ss,Contact,'|');
						getline(ss,Adress,'|');
						
						if(searchId==Id){
							
							cout<<"enter new company id:";
							getline(cin ,Id);
						 while (isCompanyIdExist(id)) {
    cout << "ID already exists in company records. Use another ID: ";
    getline(cin, id);
}
							cout<<"enter new company name:";
							getline(cin ,Name);
								while (isValidName(Name)==false) {
        cout << "Invalid name. Try again: ";
        getline(cin, Name);
    }
     while(ifcompanyExists(Name)==true){
            	cout<<"this comapny already exist :";
            	getline(cin, Name);
            	
			}
							cout<<"enter new contact no:";
							getline(cin,Contact);
								while(isValidPhone(Contact)==false){
				cout<<"invalid phone number Enter again phone no:"<<endl;
				
				getline(cin ,Contact);
			}
			 while(isPhoneDuplicate(Contact)==true){
            	cout<<"phone number already exist:";
            	getline(cin, Contact);
			}
							cout<<"enter new company adress:";
							getline(cin,Adress);
							found=1;
						}
						outfile<<Id<<"|"<<Name<<"|"<<Contact<<"|"<<Adress<<endl;
					}
					infile.close();
					outfile.close();
					
					remove("company.txt");
					rename("temp.txt","company.txt");
					if(found==1){
						cout<<"data update succecfully.";
					}else{
						cout<<"data not fount";
					}
					
					
		
            system("pause");
            system("cls");
            goto companymenu;
        } else if (choice == 3) {
            system("cls");
          string Id,Name,Contact,Adress,line;
			cout<<"----delete company data---- "<<endl;
				ifstream infile("company.txt");
					ofstream outfile("temp.txt");
					if(!infile){
						cout<<"error opening file for reading.";
						return 1;
					}
					string searchId;
					cout<<"enter company id for delete data:";
					getline(cin ,searchId);
					int found=0;
					while(getline(infile,line)){
						stringstream ss(line);
						getline(ss,Id,'|');
						getline(ss,Name,'|');
						getline(ss,Contact,'|');
						getline(ss,Adress,'|');
						if(searchId==Id){
							
							
							found=1;
							continue;
						}
						outfile<<Id<<"|"<<Name<<"|"<<Contact<<"|"<<Adress<<endl;
					}
					infile.close();
					outfile.close();
					
					remove("company.txt");
					rename("temp.txt","company.txt");
					if(found==1){
						cout<<"data delete succecfully.";
					}else{
						cout<<"data not fount";
					}
            system("pause");
             system("cls");
            goto companymenu;
        } else if (choice == 4) {
            
            cout<<"----Display company data----"<<endl;
			ifstream infile("company.txt");
			if(!infile){
				cout<<"error opening file for reading";
				return 1;
			}
          string line;
			while(getline(infile,line)){
				stringstream ss(line);
				getline(ss,id,'|');
				getline(ss,name,'|');
				getline(ss,cont,'|');
				getline(ss,adress,'|');
				cout<<"company id:"<<id<<endl;
				cout<<"company name:"<<name<<endl;
				cout<<"contact no:"<<cont<<endl;
				cout<<"adress:"<<adress<<endl;
				cout<<"___________"<<endl;
			}
		infile.close();
            system("pause");
            system("cls");
            goto companymenu;
        } else if (choice == 5) {
            goto mainmenu;
        } 
    } else if (choices == 3) {
    employeemenu:

        cout << "----Employee Management---" << endl;
        cout << "'1' for Add employee data." << endl;
        cout << "'2' for Update employee data." << endl;
        cout << "'3' for Delete employee data." << endl;
        cout << "'4' for Display employee data." << endl;
        cout << "'5' to Return to Main Menu." << endl;
        cout << "Enter your choice: ";
        
        cin>>choice;
        while (cin.fail() || choice < 1 || choice > 5) {
    cin.clear(); 
    cin.ignore(1000, '\n'); 
    cout << " Invalid choice. Please enter (1 to 5): ";
    cin >> choice;
}
      
        cin.ignore();
        system("cls");
        if (choice == 1) {
        	 
            employdata();
            system("pause");
            system("cls");
            goto employeemenu;
        } else if (choice == 2) {
        	 
            updateEmployData();
           system("pause");
           system("cls");
            goto employeemenu;
        } else if (choice == 3) {
        	 
            delEmployData();
         system("pause");
         system("cls");
            goto employeemenu;
        } else if (choice == 4) {
        	 
            displayEmployData();
            system("pause");
            system("cls");
            goto employeemenu;
        } else if (choice == 5) {
            goto mainmenu;
        } 
    } else if (choices == 4) {
    callmenu:
       
        cout << "----Call Record Management---" << endl;
        cout << "'1' for Add call record." << endl;
        cout << "'2' for Delete call record." << endl;
        cout << "'3' for Display call records." << endl;
        cout << "'4' to Return to Main Menu." << endl;
        cout << "Enter your choice: ";
        
      cin>>choice;
      while (cin.fail() || choice < 1 || choice > 4) {
    cin.clear(); 
    cin.ignore(1000, '\n'); 
    cout << " Invalid choice. Please enter (1 to 4): ";
    cin >> choice;
}
      
        cin.ignore();
        system("cls");
        if (choice == 1) {
       
            addCallRecord();
            system("pause");
            	system("cls");
            goto callmenu;
        } else if (choice == 2) {
        
            delCallData();
            system("pause");
            	system("cls");
            goto callmenu;
        } else if (choice == 3) {
        
            diplaycallData();
            system("pause");
            	system("cls");
            goto callmenu;
        } else if (choice == 4) {
        
            goto mainmenu;
        } 
    } else if (choices == 5) {
        cout << "Exiting the program." << endl;
        
       return 0;
    } 

    return 0;
}

